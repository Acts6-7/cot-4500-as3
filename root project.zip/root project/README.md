# Numerical Methods for Solving ODEs

## Overview
This project implements **Euler's Method** and **Runge-Kutta Method** (4th order) for solving **Initial Value Problems** (IVPs) for Ordinary Differential Equations (ODEs). It numerically approximates the solution for:

\[
\frac{dy}{dt} = t - y^2
\]

with the given initial condition:

\[
y(0) = 1
\]

## File Structure
```
root project/
│── src/
│   ├── main/
│   │   ├── __init__.py
│   │   ├── assignment_3.py   # Implements Euler & Runge-Kutta Methods
│   ├── test/
│   │   ├── __init__.py
│   │   ├── test_assignment_3.py  # Unit tests for numerical methods
│── requirements.txt
│── README.md
```

## Implementation Details
- **Euler's Method**: A simple numerical approximation.
- **Runge-Kutta (RK4) Method**: A higher-order, more accurate approximation.

## How to Run the Program

1. **Navigate to the project directory**:
   ```bash
   cd "C:\Users\Ryush\OneDrive\Desktop\root project"
   ```
   
2. **Run the main script**:
   ```bash
   python src/main/assignment_3.py
   ```

### Expected Output:
```
Euler Method Result: 1.2446380979332121
Runge-Kutta Method Result: 1.251316587879806
```

## How to Run Unit Tests
To verify the accuracy of the numerical methods, run:
```bash
python src/test/test_assignment_3.py
```
or use:
```bash
python -m unittest discover src/test
```

## Dependencies
- Python **3.x** (Tested on Python 3.8+)
- Uses built-in `unittest` (no external dependencies required).

## Notes
- The Euler method may introduce small numerical errors due to step-size limitations.
- Runge-Kutta is a more accurate and widely used method.
