import math

def f(t, y):
    """ Function representing dy/dt = t - y^2 """
    return t - y**2

def euler_method(f, t0, y0, t_end, n):
    """ Euler's Method for solving ODEs """
    h = (t_end - t0) / n  
    t, y = t0, y0

    for _ in range(n):
        y += h * f(t, y)
        t += h

    return y

def runge_kutta_method(f, t0, y0, t_end, n):
    """ 4th-order Runge-Kutta Method for solving ODEs """
    h = (t_end - t0) / n  
    t, y = t0, y0

    for _ in range(n):
        k1 = h * f(t, y)
        k2 = h * f(t + h/2, y + k1/2)
        k3 = h * f(t + h/2, y + k2/2)
        k4 = h * f(t + h, y + k3)
        y += (k1 + 2*k2 + 2*k3 + k4) / 6
        t += h

    return y

if __name__ == "__main__":
    t0, y0, t_end, iterations = 0, 1, 2, 10

    euler_result = euler_method(f, t0, y0, t_end, iterations)
    runge_kutta_result = runge_kutta_method(f, t0, y0, t_end, iterations)

    print(f"Euler Method Result: {euler_result}")
    print(f"Runge-Kutta Method Result: {runge_kutta_result}")
