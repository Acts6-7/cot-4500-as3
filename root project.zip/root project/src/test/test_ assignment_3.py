import unittest
import sys
import os

src_main_path = r"C:\Users\Ryush\OneDrive\Desktop\root project\src\main"
sys.path.insert(0, src_main_path) 

try:
    from assignment_3 import euler_method, runge_kutta_method, f
except ModuleNotFoundError as e:
    print("Error importing assignment_3:", e)
    print("Make sure assignment_3.py is located in:", src_main_path)
    sys.exit(1)

class TestODEMethods(unittest.TestCase):

    def test_euler_method(self):
        """ Test Euler's method with the given problem """
        t0, y0, t_end, iterations = 0, 1, 2, 10
        expected_output = 1.2448380879332121
        result = euler_method(f, t0, y0, t_end, iterations)
        
        print(f"Euler Method Output: {result}, Expected: {expected_output}")
        
        self.assertAlmostEqual(result, expected_output, places=3)

    def test_runge_kutta_method(self):
        """ Test Runge-Kutta method with the given problem """
        t0, y0, t_end, iterations = 0, 1, 2, 10
        expected_output = 1.2513165878789086
        result = runge_kutta_method(f, t0, y0, t_end, iterations)
        
        print(f"Runge-Kutta Method Output: {result}, Expected: {expected_output}")
        
        self.assertAlmostEqual(result, expected_output, places=5)

if __name__ == "__main__":
    unittest.main()
